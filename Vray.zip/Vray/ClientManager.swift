//
//  ClientManager.swift
//  Vethentia
//
//  Created by Carolyn Lee on 11/21/16.
//  Copyright © 2016 Carolyn Lee. All rights reserved.
//

import Foundation

class ClientManager {
    //static let sharedClient = MSClient(applicationURLString: "http://vethentiaservices.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=ykhwSlcjR3dSYdi6EijMmI+eOgFT15Vggg7cra8mmKY=")
}
