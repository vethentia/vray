//
//  HubInfo.h
//  Vethentia
//
//  Created by Carolyn Lee on 11/21/16.
//  Copyright © 2016 Carolyn Lee. All rights reserved.
//

#ifndef HubInfo_h
#define HubInfo_h

    #define HUBNAME @"VethentiaTestNotificationHub"
    #define HUBLISTENACCESS @"Endpoint=sb://vethentiaservices.servicebus.windows.net/;SharedAccessKeyName=DefaultFullSharedAccessSignature;SharedAccessKey=ykhwSlcjR3dSYdi6EijMmI+eOgFT15Vggg7cra8mmKY="

#endif /* HubInfo_h */
