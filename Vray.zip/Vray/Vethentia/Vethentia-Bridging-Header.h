//
//  Vethentia-Bridging-Header.h
//  Vethentia
//
//  Created by Carolyn Lee on 11/21/16.
//  Copyright © 2016 Carolyn Lee. All rights reserved.
//

#ifndef Vethentia_Bridging_Header_h
#define Vethentia_Bridging_Header_h

#import <WindowsAzureMessaging/WindowsAzureMessaging.h>
#import <WindowsAzureMobileServices/WindowsAzureMobileServices.h>
#import <Stripe/Stripe.h>
#import "HubInfo.h"

#endif /* Vethentia_Bridging_Header_h */
