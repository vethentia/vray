//
//  Transaction+CoreDataClass.swift
//  
//
//  Created by Carolyn Lee on 12/18/16.
//
//  This file was automatically generated and should not be edited.
//

import Foundation
import CoreData

@objc(Transaction)
public class Transaction: NSManagedObject {

}
